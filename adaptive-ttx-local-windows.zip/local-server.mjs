import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { handle } from './worker.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.ttf':'font/ttf' };

export async function createLocalServer({ dataDir = path.join(root, 'data'), port = 3000 } = {}) {
  await fs.mkdir(dataDir, { recursive:true });
  const uploads = path.join(dataDir, 'uploads');
  await fs.mkdir(uploads, { recursive:true });
  const sqlite = new DatabaseSync(path.join(dataDir, 'projects.sqlite'), { timeout:5000 });
  sqlite.exec('PRAGMA foreign_keys = ON');
  sqlite.exec('CREATE TABLE IF NOT EXISTS local_migrations (name TEXT PRIMARY KEY, hash TEXT NOT NULL)');
  const migrationDir = path.join(root, 'drizzle');
  for (const name of (await fs.readdir(migrationDir)).filter(n=>n.endsWith('.sql')).sort()) {
    const sql = await fs.readFile(path.join(migrationDir, name), 'utf8');
    const hash = createHash('sha256').update(sql).digest('hex');
    const prior = sqlite.prepare('SELECT hash FROM local_migrations WHERE name = ?').get(name);
    if (prior) {
      if (prior.hash !== hash) throw Error('A previously applied database migration changed: '+name);
      continue;
    }
    sqlite.exec('BEGIN IMMEDIATE');
    try {
      for (const statement of sql.split('--> statement-breakpoint')) if (statement.trim()) sqlite.exec(statement);
      sqlite.prepare('INSERT INTO local_migrations (name,hash) VALUES (?,?)').run(name,hash);
      sqlite.exec('COMMIT');
    } catch (error) { sqlite.exec('ROLLBACK'); sqlite.close(); throw error; }
  }
  const filePath = key => {
    if (!key.split('/').every(part=>/^[a-zA-Z0-9_-]+$/.test(part))) throw Error('Invalid image key.');
    return path.join(uploads, ...key.split('/'));
  };
  const bucket = {
    async put(key, bytes, metadata) {
      const base=filePath(key);await fs.mkdir(path.dirname(base),{recursive:true});
      const temporary=base+'.'+randomUUID()+'.tmp';
      await fs.writeFile(temporary,new Uint8Array(bytes));await fs.rename(temporary,base+'.bin');
      await fs.writeFile(base+'.json',JSON.stringify(metadata));
    },
    async get(key) {
      const base=filePath(key);
      try { const [bytes,metadata]=await Promise.all([fs.readFile(base+'.bin'),fs.readFile(base+'.json','utf8')]);return {body:bytes,httpMetadata:JSON.parse(metadata).httpMetadata}; }
      catch(error) { if(error.code==='ENOENT')return null;throw error; }
    },
    async list({prefix}) {
      const objects=[];
      async function walk(dir) { for(const entry of await fs.readdir(dir,{withFileTypes:true})) { const name=path.join(dir,entry.name);if(entry.isDirectory())await walk(name);else if(entry.name.endsWith('.bin')) { const key=path.relative(uploads,name).split(path.sep).join('/').slice(0,-4);if(key.startsWith(prefix))objects.push({key}); } } }
      await walk(uploads);return {objects,truncated:false};
    },
    async delete(keys) { for(const key of typeof keys==='string'?[keys]:keys) { const base=filePath(key);await fs.rm(base+'.bin',{force:true});await fs.rm(base+'.json',{force:true}); } }
  };
  const env={ BUCKET:bucket, DB:{prepare(sql) {return {bind(...args) {return {
    async first(){return sqlite.prepare(sql).get(...args)||null;},
    async all(){return {results:sqlite.prepare(sql).all(...args)};},
    async run(){const result=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(result.changes)}};}
  };}};}} };
  const server=http.createServer(async(req,res)=>{
    try {
      const actualPort=server.address().port;
      if(!new Set(['localhost:'+actualPort,'127.0.0.1:'+actualPort]).has(req.headers.host)||req.headers['sec-fetch-site']==='cross-site') {
        res.writeHead(403,{'Content-Type':'text/plain'});res.end('This demo is available only on this laptop.');return;
      }
      const url=new URL(req.url,'http://'+req.headers.host);
      const headers=new Headers();
      for(const [name,value] of Object.entries(req.headers)) if(value!==undefined) headers.set(name,Array.isArray(value)?value.join(', '):value);
      // Local mode deliberately uses a single laptop account. No ChatGPT identity is needed.
      headers.set('oai-authenticated-user-id','local-demo');
      const chunks=[];let size=0;
      for await(const chunk of req){size+=chunk.length;if(size>7*1024*1024){res.writeHead(413);res.end('Request too large.');return;}chunks.push(chunk);}
      const request=new Request(url,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
      const response=await handle(request,env);
      if(response){res.writeHead(response.status,Object.fromEntries(response.headers));res.end(req.method==='HEAD'?undefined:Buffer.from(await response.arrayBuffer()));return;}
      if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end('Method not allowed');return;}
      const publicRoot=path.join(root,'public');
      const relative=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
      const filename=path.resolve(publicRoot,'.'+relative);
      if(!filename.startsWith(publicRoot+path.sep)){res.writeHead(404);res.end('Not found');return;}
      let bytes;
      try{bytes=await fs.readFile(filename);}catch(error){if(['ENOENT','EISDIR'].includes(error.code)){res.writeHead(404);res.end('Not found');return;}throw error;}
      res.writeHead(200,{'Content-Type':mime[path.extname(filename)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      res.end(req.method==='HEAD'?undefined:bytes);
    }catch(error){console.error('Local demo:',error.message);if(!res.headersSent)res.writeHead(500,{'Content-Type':'text/plain'});res.end('The local demo could not complete this request. Check the terminal.');}
  });
  server.requestTimeout=30000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
  let closed=false;
  return {server,url:'http://localhost:'+server.address().port,dataDir,async close(){if(closed)return;closed=true;server.closeAllConnections();await new Promise(resolve=>server.close(resolve));sqlite.close();}};
}

if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
  const port=Number(process.env.PORT||3000);
  if(!Number.isInteger(port)||port<1||port>65535){console.error('PORT must be a number between 1 and 65535.');process.exitCode=1;}
  else try{
    const demo=await createLocalServer({port});
    console.log('\nDynamic TTX - Laptop demo\nOpen '+demo.url+' in your browser.\nProjects and images: '+demo.dataDir+'\nKeep this terminal open. Press Ctrl+C to stop.\n');
    for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>demo.close().then(()=>process.exit(0)));
  }catch(error){console.error(error.code==='EADDRINUSE'?'Port '+port+' is already in use. Close the other app or start with a different PORT.':error.message);process.exitCode=1;}
}

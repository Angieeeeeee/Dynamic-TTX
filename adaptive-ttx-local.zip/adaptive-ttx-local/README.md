# Dynamic TTX - Laptop demo

Run the tabletop app locally, without ChatGPT, a cloud account, or internet access once Node.js is installed.

## Start

1. Install **Node.js 24** from https://nodejs.org/en/download if it is not already installed. Restart Terminal after installation.
2. Extract this ZIP. Keep the complete `adaptive-ttx-local` folder together.
3. Open Terminal (Mac) or PowerShell (Windows) in that folder.
4. Run:

       npm start

5. Open **http://localhost:3000** in your browser.

No `npm install` or build is needed to run this local demo: it uses Node.js built-ins and the included browser libraries. You can also start it with `node local-server.mjs`.

On Mac, type `cd ` in Terminal, drag the extracted folder into the Terminal window, press Enter, and then run `npm start`.
On Windows, right-click inside the extracted folder and choose Open in Terminal, then run `npm start`.

Keep the terminal open during the demo. Stop the app with Ctrl+C. Start it again with the same command; your projects remain saved.

## Data and backups

Local projects are saved to `data/projects.sqlite`. Uploaded logos and slide images are saved under `data/uploads`.
Stop the app before copying the complete `data` folder as a backup. Keep that folder when updating the code. To move a demo to a different laptop, copy the complete app folder including `data` after stopping the app.

This ZIP does not include projects or client uploads from the hosted ChatGPT version. The local app starts with an empty project list and the default water scenario bank.

## Presenting

Create or reopen a project, choose scenarios and slide images, and start the exercise. Use Open audience window and move that window to the projector or screen you share with participants. Selecting Thank you completes and saves the exercise; export its PDF from the project list.

## Local access

This mode runs only on your laptop, using one local account with no login. It listens on 127.0.0.1 and is intended for a personal demo, not a public server or team deployment.

If port 3000 is occupied:
- Mac/Linux: `PORT=3001 npm start`
- Windows PowerShell: set `$env:PORT = "3001"`, then run `npm start`

Then open http://localhost:3001.

## Cloud development files

`worker.mjs`, `db`, and `drizzle` preserve the hosted app's API and database schema. Local mode adapts the same API to SQLite and local image files. GitHub Pages alone cannot run that backend.

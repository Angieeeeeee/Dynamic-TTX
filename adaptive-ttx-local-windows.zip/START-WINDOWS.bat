@echo off
cd /d "%~dp0"
echo Starting Dynamic TTX on this laptop...
node --version
node local-server.mjs
echo.
echo The demo has stopped. If an error appeared above, install Node.js 24 and try again.
pause
